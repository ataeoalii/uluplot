===========
Uluplot
===========

Uluplot provides a plotting library to be used with Google Maps API to generate
static HTML maps. This is an extension of gmplot with additional features.
Typical usage often looks like this::

    #!/usr/bin/env python

    from uluplot import GoogleMapPlotter

