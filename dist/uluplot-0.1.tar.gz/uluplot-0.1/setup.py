from distutils.core import setup

setup(name='uluplot',
      version='0.1',
      description='Flexible plot based on gmplot',
      url='http://github.com/ulu5/uluplot',
      author='ulu5',
      author_email='ulu_5@yahoo.com',
      license='MIT',
      packages=['uluplot'])
